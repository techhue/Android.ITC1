package com.techhue.adapter;

import android.app.Activity;
import android.app.LoaderManager;
import android.content.CursorLoader;
import android.content.Loader;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.CallLog;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

import java.util.ArrayList;

public class MyActivity extends Activity {
    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        final ListView myListView = (ListView) findViewById(R.id.my_list_view);

        int layoutID = android.R.layout.simple_list_item_1;


        /**
         *  Creating and applying an Adapter
         */

        ArrayList<String> myStringArray = new ArrayList<String>();

        ArrayAdapter<String> myAdapterInstance;
        myAdapterInstance =
                new ArrayAdapter<String>(this, layoutID, myStringArray);

        myListView.setAdapter(myAdapterInstance);


        myStringArray.add("The");
        myStringArray.add("quick");
        myStringArray.add("green");
        myStringArray.add("Android");
        myStringArray.add("jumped");
        myStringArray.add("over");
        myStringArray.add("the");
        myStringArray.add("lazy");
        myAdapterInstance.notifyDataSetChanged();



        /**
         * Listing 4-21: Using Customized Array Adapter with MyClass.
         **/
        /*
        ArrayList<MyClass> myClassesArray = new ArrayList<MyClass>();
        myClassesArray.add(new MyClass("khojo"));
        myClassesArray.add(new MyClass("mojo"));
        myClassesArray.add(new MyClass("tojo"));
        myClassesArray.add(new MyClass("dojo"));
        MyArrayAdapter myArrayAdapter = new MyArrayAdapter(this, layoutID, myClassesArray);
        myListView.setAdapter(myArrayAdapter);
        */

        /**
         * Listing 4-22: Creating a Simple Cursor Adapter
         */
        /*
        LoaderManager.LoaderCallbacks<Cursor> loaded = new LoaderManager.LoaderCallbacks<Cursor>()
        {
            public Loader<Cursor> onCreateLoader(int id, Bundle args)
            {
                CursorLoader loader = new CursorLoader(MyActivity.this, CallLog.CONTENT_URI, null, null, null, null);
                return loader;
            }

            public void onLoadFinished(Loader<Cursor> loader, Cursor cursor)
            {

                String[] fromColumns = new String[] {
                        CallLog.Calls.CACHED_NAME,
                        CallLog.Calls.NUMBER
                };

                int[] toLayoutIDs = new int[] {
                        R.id.nameTextView,
                        R.id.numberTextView
                };

                SimpleCursorAdapter myCursorAdapter = new SimpleCursorAdapter(MyActivity.this, R.layout.mysimplecursorlayout, cursor, fromColumns, toLayoutIDs);
                myListView.setAdapter(myCursorAdapter);
            }

            public void onLoaderReset(Loader<Cursor> loader)
            {

            }
        };

        getLoaderManager().initLoader(0, null, loaded);
        */
    }
}