package com.techhue.android;

/**
 * Listing 3-7: Skeleton Application class
 * Listing 3-8: Overriding the Application Lifecycle Handlers
 */

import android.app.Application;
import android.content.res.Configuration;
import android.util.Log;

public class MyApplication extends Application
{

    private static MyApplication singleton;
    private static String TAG = "com.techhue.configuration_changes.MyApplication";

    // Returns the application instance
    public static MyApplication getInstance()
    {
        return singleton;
    }

    @Override
    public final void onCreate() {
        super.onCreate();
        singleton = this;
        Log.d(TAG, "onCreate");
    }

    @Override
    public final void onLowMemory() {
        super.onLowMemory();
        Log.d(TAG, "onLowMemory");
    }

    @Override
    public final void onTrimMemory(int level) {
        super.onTrimMemory(level);
        Log.d(TAG, "onTrimMemory");
    }

    @Override
    public final void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Log.d(TAG, "onConfigurationChanged");
    }
}
