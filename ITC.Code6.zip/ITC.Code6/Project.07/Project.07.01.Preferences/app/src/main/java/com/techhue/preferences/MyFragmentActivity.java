package com.techhue.preferences;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;

public class MyFragmentActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_fragment);

        FragmentManager fragmentManager = getFragmentManager();

        MyFragment myFragment = (MyFragment) fragmentManager.findFragmentById(R.id.myFragmentPlace);

        if (myFragment == null)
        {
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.add(R.id.myFragmentPlace, new MyFragment());
            fragmentTransaction.commit();
        }
    }
}
